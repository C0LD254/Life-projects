﻿#nullable enable
using Microsoft.WindowsAPICodePack.Shell;
using Microsoft.WindowsAPICodePack.Shell.PropertySystem;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Picturesort
{
    public partial class Form1 : Form
    {
        #region Поля и Конструктор

        private List<string> imageFiles = new();
        private int currentIndex = 0;
        private int initialCount = 0;
        private string currentFolderPath = "";
        private bool isMovingFile = false;
        private List<PictureBox> starBoxes = new();
        private int currentHoverRating = 0;
        private int currentSavedRating = 0;
        private ToolTip starToolTip = new ToolTip();
        private string? rootFolderPath = "";
        private CancellationTokenSource? imageLoadCts;
        private readonly SemaphoreSlim previewSemaphore = new(1, 1);

        private Image StarFilled => Properties.Resources.star_filled;
        private Image StarEmpty => Properties.Resources.star_empty;

        public Form1()
        {
            InitializeComponent();
            txtPath.ReadOnly = true;
            txtPath.TabStop = false;
            this.WindowState = FormWindowState.Maximized;
            this.KeyPreview = true;
            this.KeyDown += Form1_KeyDown;

            chkAuswhall.CheckedChanged += chkAuswhall_CheckedChanged;

            btnSelect.Click += btnSelect_Click;
            btnRight.Click += btnRight_Click;
            btnLeft.Click += btnLeft_Click;
            btnGood.Click += btnGood_Click;
            btnBad.Click += btnBad_Click;
            btnFlip.Click += btnFlip_Click;

            lstInfo.View = View.Details;
            lstInfo.Columns.Add("Name", 100);
            lstInfo.Columns.Add("Größe", 100);
            lstInfo.Columns.Add("Abmessungen", 100);
            lstInfo.Columns.Add("Bewertung", 100);

            SetupStarRating();

            starToolTip.IsBalloon = true;
            starToolTip.ToolTipTitle = "Info";
            starToolTip.AutoPopDelay = 3000;
            starToolTip.InitialDelay = 500;
            starToolTip.ReshowDelay = 500;

            UpdateCountLabel();
        }

        #endregion


        #region Настройка и Работа со Звездным Рейтингом

        private void SetupStarRating()
        {
            starBoxes = new List<PictureBox> { star1, star2, star3, star4, star5 };

            for (int i = 0; i < starBoxes.Count; i++)
            {
                var star = starBoxes[i];
                star.Tag = i + 1;
                star.SizeMode = PictureBoxSizeMode.Zoom;
                star.Cursor = Cursors.Hand;

                star.MouseEnter += Star_MouseEnter;
                star.MouseLeave += Star_MouseLeave;
                star.Click += Star_Click;
            }

            UpdateStarRatingUI();
        }

        #endregion


        #region Работа с Папками

        private void SetCurrentFolder(string folder)
        {
            if (!chkAuswhall.Checked)
            {
                if (!IsSameOrSubdirectory(rootFolderPath ?? "", folder))
                {
                    MessageBox.Show("Unterordner können nur bei aktivierter Option ausgewählt werden.",
                                    "Zugriff verweigert", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }

            currentFolderPath = folder;
            txtPath.Text = currentFolderPath;
            _ = LoadImagesFromFolder(currentFolderPath);
        }

        private bool IsSameOrSubdirectory(string basePath, string testPath)
        {
            var baseDir = Path.GetFullPath(basePath.TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar);
            var testDir = Path.GetFullPath(testPath.TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar);

            return testDir.StartsWith(baseDir, StringComparison.OrdinalIgnoreCase);
        }

        #endregion


        #region Buttons
        private async void btnSelect_Click(object? sender, EventArgs e)
        {
            using var dialog = new FolderBrowserDialog();
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                string selectedPath = dialog.SelectedPath;

                if (!chkAuswhall.Checked)
                {
                    if (!string.IsNullOrEmpty(rootFolderPath))
                    {
                        if (!IsSameOrSubdirectory(rootFolderPath, selectedPath))
                        {
                            MessageBox.Show($"Bitte wählen Sie nur den Stammordner:\n{rootFolderPath}",
                                            "Ordnerwahl eingeschränkt", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                    }
                    else
                    {
                        rootFolderPath = selectedPath;
                    }
                }
                else
                {
                    if (string.IsNullOrEmpty(rootFolderPath))
                        rootFolderPath = selectedPath;
                }

                currentFolderPath = selectedPath;
                txtPath.Text = currentFolderPath;

                await LoadImagesAccordingToMode();
            }
        }



        private void btnFlip_Click(object sender, EventArgs e)
        {
            if (pcbPhoto.Image == null) return;

            using var oldImage = pcbPhoto.Image;
            Image rotatedImage = (Image)oldImage.Clone();
            rotatedImage.RotateFlip(RotateFlipType.Rotate270FlipNone);

            pcbPhoto.Image = rotatedImage;
        }



        private void Star_MouseEnter(object? sender, EventArgs e)
        {
            if (sender is PictureBox pb && pb.Tag is int value)
            {
                currentHoverRating = value;
                UpdateStarRatingUI();
            }
        }


        private void Star_MouseLeave(object? sender, EventArgs e)
        {
            currentHoverRating = 0;
            UpdateStarRatingUI();
        }


        private void Star_Click(object? sender, EventArgs e)
        {
            if (!CheckIfImageAvailable())
            {
                MessageBox.Show("Bitte wählen Sie zuerst ein Foto aus, um eine Bewertung zu vergeben.",
                                "Kein Foto ausgewählt", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (sender is PictureBox pb && pb.Tag is int value)
            {
                if (currentSavedRating == value)
                {
                    currentSavedRating = 0;
                    SetRatingForCurrentImage(0);
                }
                else
                {
                    currentSavedRating = value;
                    SetRatingForCurrentImage(value);
                }

                UpdateStarRatingUI();
            }
        }


        private void UpdateStarRatingUI()
        {
            int ratingToShow = currentHoverRating > 0 ? currentHoverRating : currentSavedRating;

            for (int i = 0; i < starBoxes.Count; i++)
            {
                starBoxes[i].Image = (i < ratingToShow) ? StarFilled : StarEmpty;
            }
        }


        private void SetRatingForCurrentImage(int rating)
        {
            if (imageFiles.Count == 0 || currentIndex < 0 || currentIndex >= imageFiles.Count) return;

            string path = imageFiles[currentIndex];

            try
            {
                using var shellFile = ShellFile.FromFilePath(path);
                using var writer = shellFile.Properties.GetPropertyWriter();

                uint shellRating = (uint)Math.Min(rating * 20, 99);
                writer.WriteProperty(SystemProperties.System.Rating, shellRating);

                currentSavedRating = rating;
                UpdateImageInfo(path, pcbPhoto.Image!);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Fehler beim Speichern des Ratings:\n" + ex.Message,
                                "Rating Fehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private int GetFileRating(string path)
        {
            try
            {
                var shellFile = ShellFile.FromFilePath(path);
                uint? rawRating = shellFile.Properties.System.Rating.Value;
                return rawRating.HasValue ? (int)Math.Round(rawRating.Value / 20.0) : 0;
            }
            catch
            {
                return 0;
            }
        }


        private async void Form1_KeyDown(object? sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.G)
            {
                await btnGood_ClickAsync(null, EventArgs.Empty);
            }
            else if (e.KeyCode == Keys.B)
            {
                await btnBad_ClickAsync(null, EventArgs.Empty);
            }
            else if (e.KeyCode == Keys.R)
            {
                btnFlip.PerformClick();
                e.Handled = true;
            }
        }

        private SemaphoreSlim navigationSemaphore = new SemaphoreSlim(1, 1);
        private void btnRight_Click(object? sender, EventArgs e)
        {
            _ = btnRight_ClickAsync(sender, e);
        }


        private async Task btnRight_ClickAsync(object? sender, EventArgs e)
        {
            if (imageFiles.Count == 0) return;

            await navigationSemaphore.WaitAsync();
            try
            {
                btnLeft.Enabled = btnRight.Enabled = false;

                currentIndex = (currentIndex + 1) % imageFiles.Count;
                await DisplayImageAsyncFast();
                await UpdatePreviewImagesSafeAsync();
            }
            finally
            {
                btnLeft.Enabled = btnRight.Enabled = true;
                navigationSemaphore.Release();
            }
        }


        private async void btnLeft_Click(object? sender, EventArgs e)
        {
            await btnLeft_ClickAsync(sender, e);
        }

        private async Task btnLeft_ClickAsync(object? sender, EventArgs e)
        {
            if (imageFiles.Count == 0) return;

            await navigationSemaphore.WaitAsync();
            try
            {
                btnLeft.Enabled = btnRight.Enabled = false;

                currentIndex = (currentIndex - 1 + imageFiles.Count) % imageFiles.Count;
                await DisplayImageAsyncFast();
                await UpdatePreviewImagesSafeAsync();
            }
            finally
            {
                btnLeft.Enabled = btnRight.Enabled = true;
                navigationSemaphore.Release();
            }
        }


        private async void btnGood_Click(object? sender, EventArgs e)
        {
            await HandleGoodBadAsync("Gut");
        }


        private async Task btnGood_ClickAsync(object? sender, EventArgs e)
        {
            if (isMovingFile || !CheckIfImageAvailable()) return;

            isMovingFile = true;
            btnLeft.Enabled = btnRight.Enabled = false;
            try
            {
                await MoveCurrentImageToSubfolder("Gut");
            }
            finally
            {
                btnLeft.Enabled = btnRight.Enabled = true;
                isMovingFile = false;
            }
        }


        private async void btnBad_Click(object? sender, EventArgs e)
        {
            await HandleGoodBadAsync("Bad");
        }

        private SemaphoreSlim moveSemaphore = new SemaphoreSlim(1, 1);

        private async Task HandleGoodBadAsync(string subfolderName)
        {
            if (isMovingFile || !CheckIfImageAvailable()) return;

            await moveSemaphore.WaitAsync();
            try
            {
                isMovingFile = true;
                btnLeft.Enabled = btnRight.Enabled = false;
                await MoveCurrentImageToSubfolder(subfolderName);
            }
            finally
            {
                btnLeft.Enabled = btnRight.Enabled = true;
                isMovingFile = false;
                moveSemaphore.Release();
            }
        }

        //private void ReloadImageListAndFixIndex()
        //{
        //    if (string.IsNullOrEmpty(currentFolderPath)) return;

        //    var oldImage = imageFiles.Count > currentIndex ? imageFiles[currentIndex] : null;

        //    imageFiles = Directory.GetFiles(currentFolderPath)
        //                          .Where(f => IsImageFile(f))
        //                          .OrderBy(f => f)
        //                          .ToList();

        //    if (imageFiles.Count == 0)
        //    {
        //        currentIndex = -1;
        //        return;
        //    }

        //    if (!string.IsNullOrEmpty(oldImage) && imageFiles.Contains(oldImage))
        //    {
        //        currentIndex = imageFiles.IndexOf(oldImage);
        //    }
        //    else
        //    {
        //        currentIndex = Math.Min(currentIndex, imageFiles.Count - 1);
        //    }
        //}


        
        private async Task btnBad_ClickAsync(object? sender, EventArgs e)
        {
            if (isMovingFile || !CheckIfImageAvailable()) return;

            isMovingFile = true;
            btnLeft.Enabled = btnRight.Enabled = false;
            try
            {
                await MoveCurrentImageToSubfolder("Bad");

                //ReloadImageListAndFixIndex();

                if (imageFiles.Count == 0)
                {
                    pcbPhoto.Image?.Dispose();
                    pcbPhoto.Image = null;
                    pcbPrevious.Image?.Dispose();
                    pcbPrevious.Image = null;
                    pcbNext.Image?.Dispose();
                    pcbNext.Image = null;
                    return;
                }

                await DisplayImageAsyncFast();
                await UpdatePreviewImagesSafeAsync();
            }
            finally
            {
                btnLeft.Enabled = btnRight.Enabled = true;
                isMovingFile = false;
            }
        }
        #endregion


        #region Поля и ресурсы
        private CancellationTokenSource? previewCts;
        #endregion


        #region Обновление превью изображений
        private async Task UpdatePreviewImagesSafeAsync()
        {
            previewCts?.Cancel();
            previewCts = new CancellationTokenSource();
            var token = previewCts.Token;

            await previewSemaphore.WaitAsync();
            try
            {
                Image? prevImage = null;
                Image? nextImage = null;

                if (currentIndex > 0)
                {
                    string prevPath = imageFiles[currentIndex - 1];
                    if (File.Exists(prevPath))
                    {
                        if (token.IsCancellationRequested) return;
                        prevImage = await Task.Run(() => CreateThumbnail(prevPath, pcbPrevious.Width, pcbPrevious.Height));
                        if (token.IsCancellationRequested)
                        {
                            prevImage.Dispose();
                            return;
                        }
                    }
                }

                if (currentIndex < imageFiles.Count - 1)
                {
                    string nextPath = imageFiles[currentIndex + 1];
                    if (File.Exists(nextPath))
                    {
                        if (token.IsCancellationRequested) return;
                        nextImage = await Task.Run(() => CreateThumbnail(nextPath, pcbNext.Width, pcbNext.Height));
                        if (token.IsCancellationRequested)
                        {
                            nextImage.Dispose();
                            return;
                        }
                    }
                }

                pcbPrevious.Invoke(() =>
                {
                    pcbPrevious.Image?.Dispose();
                    pcbPrevious.Image = prevImage;
                });

                pcbNext.Invoke(() =>
                {
                    pcbNext.Image?.Dispose();
                    pcbNext.Image = nextImage;
                });
            }
            catch (OperationCanceledException)
            {
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Preview error: " + ex.Message);
            }
            finally
            {
                previewSemaphore.Release();
            }
        }
        #endregion


        #region Создание и изменение изображений (Thumbnail, Resize)
        private Image CreateThumbnail(string path, int width, int height)
        {
            using var fs = new FileStream(path, FileMode.Open, FileAccess.Read);
            using var originalImage = Image.FromStream(fs);

            var thumbnail = new Bitmap(width, height);
            using (var g = Graphics.FromImage(thumbnail))
            {
                g.CompositingQuality = System.Drawing.Drawing2D.CompositingQuality.HighQuality;
                g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;

                var destRect = GetScaledRectangle(originalImage.Size, new Size(width, height));
                g.DrawImage(originalImage, destRect);
            }
            return thumbnail;
        }

        private Rectangle GetScaledRectangle(Size original, Size target)
        {
            float ratio = Math.Min((float)target.Width / original.Width, (float)target.Height / original.Height);
            int width = (int)(original.Width * ratio);
            int height = (int)(original.Height * ratio);
            int x = (target.Width - width) / 2;
            int y = (target.Height - height) / 2;
            return new Rectangle(x, y, width, height);
        }

        private Image ResizeImage(Image image, int maxWidth, int maxHeight)
        {
            int newWidth = image.Width;
            int newHeight = image.Height;

            if (image.Width > maxWidth || image.Height > maxHeight)
            {
                double ratioX = (double)maxWidth / image.Width;
                double ratioY = (double)maxHeight / image.Height;
                double ratio = Math.Min(ratioX, ratioY);

                newWidth = (int)(image.Width * ratio);
                newHeight = (int)(image.Height * ratio);
            }

            Bitmap newImage = new Bitmap(newWidth, newHeight);
            using (Graphics g = Graphics.FromImage(newImage))
            {
                g.DrawImage(image, 0, 0, newWidth, newHeight);
            }

            return newImage;
        }
        #endregion


        #region Обработчик чекбокса выбора папки
        private async void chkAuswhall_CheckedChanged(object? sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(currentFolderPath)) return;

            if (!chkAuswhall.Checked)
            {
                if (!string.IsNullOrEmpty(rootFolderPath) &&
                    !string.Equals(currentFolderPath, rootFolderPath, StringComparison.OrdinalIgnoreCase))
                {
                    currentFolderPath = rootFolderPath;
                    txtPath.Text = currentFolderPath;
                }
            }
            await LoadImagesAccordingToMode();
        }
        #endregion


        #region Загрузка и фильтрация изображений
        private async Task LoadImagesAccordingToMode()
        {
            if (chkAuswhall.Checked)
            {
                var supportedExtensions = new[] { ".jpg", ".jpeg", ".png", ".bmp", ".gif" };
                imageFiles = Directory.GetFiles(currentFolderPath)
                    .Where(f => supportedExtensions.Contains(Path.GetExtension(f).ToLower()))
                    .ToList();
            }
            else
            {
                var supportedExtensions = new[] { ".jpg", ".jpeg", ".png", ".bmp", ".gif" };
                var excludeFolders = new[] { "Gut", "Bad" };
                imageFiles = await GetImageFilesExcludingSubfolders(currentFolderPath, excludeFolders, supportedExtensions);
            }

            currentIndex = 0;
            initialCount = imageFiles.Count;

            if (imageFiles.Count > 0)
                await DisplayImageAsync();
            else
            {
                pcbPhoto.Image = null;
                lstInfo.Items.Clear();
                UpdateCountLabel();
            }
        }


        private async Task LoadImagesFromFolder(string folderPath)
        {
            if (!Directory.Exists(folderPath))
            {
                MessageBox.Show("Der Ordner existiert nicht.", "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                imageLoadCts?.Cancel();
                imageLoadCts?.Dispose();
                imageLoadCts = new CancellationTokenSource();

                var allowedExtensions = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { ".jpg", ".jpeg", ".png", ".bmp", ".gif", ".tiff" };

                var searchOption = chkAuswhall.Checked ? SearchOption.AllDirectories : SearchOption.TopDirectoryOnly;

                var files = await Task.Run(() =>
                    Directory.EnumerateFiles(folderPath, "*.*", searchOption)
                        .Where(f => allowedExtensions.Contains(Path.GetExtension(f)))
                        .ToList(),
                    imageLoadCts.Token);

                imageFiles = files;
                initialCount = imageFiles.Count;
                currentIndex = 0;

                UpdateCountLabel();

                if (imageFiles.Count > 0)
                {
                    await DisplayImageAsyncFast();
                }
                else
                {
                    pcbPhoto.Image?.Dispose();
                    pcbPhoto.Image = null;
                    UpdateImageInfo(null, null);
                }
            }
            catch (OperationCanceledException)
            {
            }
            catch (Exception ex)
            {
                MessageBox.Show("Fehler beim Laden der Bilder:\n" + ex.Message, "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private async Task<List<string>> GetImageFilesExcludingSubfolders(string rootPath, string[] excludeFolders, string[] supportedExtensions)
        {
            var result = new List<string>();

            await Task.Run(() =>
            {
                var directories = new Stack<string>();
                directories.Push(rootPath);

                while (directories.Count > 0)
                {
                    var currentDir = directories.Pop();

                    var dirName = Path.GetFileName(currentDir);
                    if (excludeFolders.Contains(dirName, StringComparer.OrdinalIgnoreCase))
                    {
                        continue;
                    }

                    try
                    {
                        foreach (var subDir in Directory.GetDirectories(currentDir))
                        {
                            directories.Push(subDir);
                        }

                        var files = Directory.GetFiles(currentDir)
                            .Where(f => supportedExtensions.Contains(Path.GetExtension(f).ToLower()));

                        result.AddRange(files);
                    }
                    catch (UnauthorizedAccessException)
                    {
                    }
                }
            });
            return result;
        }
        #endregion


        #region Отображение и обновление информации о изображении
        private string RatingToStars(int rating)
        {
            return new string('★', rating) + new string('☆', 5 - rating);
        }

        private async Task DisplayImageAsync()
        {
            imageLoadCts?.Cancel();
            imageLoadCts = new CancellationTokenSource();
            var token = imageLoadCts.Token;

            try
            {
                if (imageFiles.Count == 0 || currentIndex < 0 || currentIndex >= imageFiles.Count)
                {
                    pcbPhoto.Image = null;
                    lstInfo.Items.Clear();
                    UpdateCountLabel();
                    await UpdatePreviewImagesSafeAsync();
                    return;
                }

                string path = imageFiles[currentIndex];
                if (!File.Exists(path))
                {
                    imageFiles.RemoveAt(currentIndex);
                    currentIndex = Math.Max(currentIndex, 0);
                    if (imageFiles.Count > 0)
                        await DisplayImageAsync();
                    else
                    {
                        pcbPhoto.Image = null;
                        lstInfo.Items.Clear();
                    }
                    UpdateCountLabel();
                    return;
                }

                pcbPhoto.Image?.Dispose();
                pcbPhoto.Image = null;

                await Task.Yield();

                Image img = await Task.Run(() =>
                {
                    using var fs = new FileStream(path, FileMode.Open, FileAccess.Read);
                    var ms = new MemoryStream();
                    fs.CopyTo(ms);
                    ms.Position = 0;
                    return Image.FromStream(ms);
                });

                if (token.IsCancellationRequested) return;

                pcbPhoto.Invoke(() =>
                {
                    pcbPhoto.Image = img;
                    pcbPhoto.SizeMode = PictureBoxSizeMode.Zoom;
                });

                currentSavedRating = GetFileRating(path);
                UpdateStarRatingUI();
                UpdateImageInfo(path, img);
            }
            catch (OperationCanceledException)
            {
            }
            catch (Exception ex)
            {
                MessageBox.Show("Fehler beim Laden des Bildes:\n" + ex.Message, "Ladefehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
                pcbPhoto.Image = null;
                lstInfo.Items.Clear();
            }

            UpdateCountLabel();
            await UpdatePreviewImagesSafeAsync();
        }

        private async Task DisplayImageAsyncFast()
        {
            imageLoadCts?.Cancel();
            imageLoadCts?.Dispose();
            imageLoadCts = new CancellationTokenSource();

            await previewSemaphore.WaitAsync();
            try
            {
                if (imageFiles.Count == 0 || currentIndex < 0 || currentIndex >= imageFiles.Count)
                {
                    pcbPhoto.Image?.Dispose();
                    pcbPhoto.Image = null;
                    UpdateImageInfo(null, null);
                    return;
                }

                string path = imageFiles[currentIndex];

                var img = await Task.Run(() =>
                {
                    imageLoadCts.Token.ThrowIfCancellationRequested();
                    using var temp = Image.FromFile(path);
                    return (Image)temp.Clone();
                }, imageLoadCts.Token);

                var oldImage = pcbPhoto.Image;
                pcbPhoto.Image = img;
                oldImage?.Dispose();

                currentSavedRating = GetFileRating(path);
                UpdateStarRatingUI();

                UpdateImageInfo(path, img);
            }
            catch (OperationCanceledException)
            {
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Fehler beim Laden des Bildes:\n{ex.Message}", "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                previewSemaphore.Release();
            }
        }

        private void UpdateImageInfo(string imagePath, Image image)
        {
            lstInfo.Items.Clear();

            var fileInfo = new FileInfo(imagePath);
            string name = fileInfo.Name;
            string size = FormatFileSize(fileInfo.Length);
            string dimensions = $"{image.Width} × {image.Height}";

            int rating = GetFileRating(imagePath);
            string stars = RatingToStars(rating);

            var item = new ListViewItem(name);
            item.SubItems.Add(size);
            item.SubItems.Add(dimensions);
            item.SubItems.Add(stars);

            lstInfo.Items.Add(item);
        }

        private string FormatFileSize(long bytes)
        {
            string[] sizes = { "Bytes", "KB", "MB", "GB", "TB" };
            double len = bytes;
            int order = 0;
            while (len >= 1024 && order < sizes.Length - 1)
            {
                order++;
                len /= 1024;
            }
            return $"{len:F1} {sizes[order]}";
        }
        #endregion


        #region Перемещение и проверка изображений
        private async Task MoveCurrentImageToSubfolder(string folderName)
        {
            if (imageFiles.Count == 0 || currentIndex < 0 || currentIndex >= imageFiles.Count)
                return;

            string sourcePath = imageFiles[currentIndex];

            string destFolder;
            if (chkAuswhall.Checked)
            {
                destFolder = Path.Combine(Path.GetDirectoryName(sourcePath) ?? currentFolderPath, folderName);
            }
            else
            {
                destFolder = Path.Combine(currentFolderPath, folderName);
            }

            try
            {
                if (!Directory.Exists(destFolder))
                    Directory.CreateDirectory(destFolder);

                string destPath = Path.Combine(destFolder, Path.GetFileName(sourcePath));

                if (File.Exists(destPath))
                {
                    string newFileName = $"{Path.GetFileNameWithoutExtension(destPath)}_{DateTime.Now:yyyyMMdd_HHmmss}{Path.GetExtension(destPath)}";
                    destPath = Path.Combine(destFolder, newFileName);
                }

                pcbPhoto.Image?.Dispose();
                pcbPhoto.Image = null;

                await Task.Run(() => File.Move(sourcePath, destPath));

                imageFiles.RemoveAt(currentIndex);
                currentIndex = Math.Min(currentIndex, imageFiles.Count - 1);

                if (imageFiles.Count > 0)
                    await DisplayImageAsync();
                else
                {
                    pcbPhoto.Image = null;
                    lstInfo.Items.Clear();
                    UpdateCountLabel();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Fehler beim Verschieben der Datei:\n" + ex.Message,
                                "Verschiebefehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
                if (imageFiles.Count > 0)
                    await DisplayImageAsync();
            }
        }

        private bool CheckIfImageAvailable()
        {
            if (imageFiles.Count == 0)
            {
                MessageBox.Show("Kein Foto ausgewählt.\nWählen Sie oben einen Ordner mit Fotos aus.",
                                "Kein Foto",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);
                return false;
            }
            return true;
        }

        private bool IsInsideExcludedFolder(string path, string[] excludedFolderNames)
        {
            var directoryInfo = new DirectoryInfo(path);

            while (directoryInfo != null)
            {
                if (excludedFolderNames.Contains(directoryInfo.Name, StringComparer.OrdinalIgnoreCase))
                    return true;
                directoryInfo = directoryInfo.Parent;
            }
            return false;
        }
        #endregion


        #region Обновление счетчика изображений
        private void UpdateCountLabel()
        {
            int remaining = imageFiles.Count;
            countLabel.Text = $"Fotos: {remaining} / {initialCount}";
        }
        #endregion
    }
}
