﻿namespace Picturesort
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges20 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges21 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges22 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges23 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges24 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges25 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges26 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges27 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges28 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges29 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges30 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            label1 = new Label();
            txtPath = new Guna.UI2.WinForms.Guna2TextBox();
            pcbPhoto = new Guna.UI2.WinForms.Guna2PictureBox();
            btnSelect = new Guna.UI2.WinForms.Guna2Button();
            btnLeft = new Guna.UI2.WinForms.Guna2Button();
            btnRight = new Guna.UI2.WinForms.Guna2Button();
            btnBad = new Guna.UI2.WinForms.Guna2Button();
            btnGood = new Guna.UI2.WinForms.Guna2Button();
            countLabel = new Label();
            lstInfo = new ListView();
            star1 = new Guna.UI2.WinForms.Guna2PictureBox();
            star2 = new Guna.UI2.WinForms.Guna2PictureBox();
            star3 = new Guna.UI2.WinForms.Guna2PictureBox();
            star4 = new Guna.UI2.WinForms.Guna2PictureBox();
            star5 = new Guna.UI2.WinForms.Guna2PictureBox();
            chkAuswhall = new Guna.UI2.WinForms.Guna2CheckBox();
            btnFlip = new Guna.UI2.WinForms.Guna2Button();
            pcbPrevious = new Guna.UI2.WinForms.Guna2PictureBox();
            pcbNext = new Guna.UI2.WinForms.Guna2PictureBox();
            ((System.ComponentModel.ISupportInitialize)pcbPhoto).BeginInit();
            ((System.ComponentModel.ISupportInitialize)star1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)star2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)star3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)star4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)star5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pcbPrevious).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pcbNext).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(26, 16);
            label1.Name = "label1";
            label1.Size = new Size(66, 32);
            label1.TabIndex = 0;
            label1.Text = "Pfad:";
            // 
            // txtPath
            // 
            txtPath.AccessibleRole = AccessibleRole.None;
            txtPath.BorderColor = Color.Black;
            txtPath.CustomizableEdges = customizableEdges1;
            txtPath.DefaultText = "";
            txtPath.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtPath.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtPath.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtPath.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtPath.Enabled = false;
            txtPath.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPath.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtPath.ForeColor = Color.Black;
            txtPath.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPath.Location = new Point(100, 14);
            txtPath.Margin = new Padding(5);
            txtPath.Name = "txtPath";
            txtPath.PlaceholderForeColor = Color.Black;
            txtPath.PlaceholderText = "";
            txtPath.SelectedText = "";
            txtPath.ShadowDecoration.CustomizableEdges = customizableEdges2;
            txtPath.Size = new Size(703, 43);
            txtPath.TabIndex = 1;
            // 
            // pcbPhoto
            // 
            pcbPhoto.CustomizableEdges = customizableEdges3;
            pcbPhoto.ImageRotate = 0F;
            pcbPhoto.Location = new Point(-13, 157);
            pcbPhoto.Name = "pcbPhoto";
            pcbPhoto.ShadowDecoration.CustomizableEdges = customizableEdges4;
            pcbPhoto.Size = new Size(1513, 917);
            pcbPhoto.TabIndex = 2;
            pcbPhoto.TabStop = false;
            // 
            // btnSelect
            // 
            btnSelect.Animated = true;
            btnSelect.BackColor = Color.Transparent;
            btnSelect.CustomizableEdges = customizableEdges5;
            btnSelect.DisabledState.BorderColor = Color.DarkGray;
            btnSelect.DisabledState.CustomBorderColor = Color.DarkGray;
            btnSelect.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnSelect.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnSelect.FillColor = Color.Transparent;
            btnSelect.Font = new Font("Segoe UI", 9F);
            btnSelect.ForeColor = Color.Transparent;
            btnSelect.Image = Properties.Resources.folder_clipart_folder_icon_1750920313_upscaled;
            btnSelect.ImageSize = new Size(60, 50);
            btnSelect.Location = new Point(824, 4);
            btnSelect.Name = "btnSelect";
            btnSelect.ShadowDecoration.CustomizableEdges = customizableEdges6;
            btnSelect.Size = new Size(67, 64);
            btnSelect.TabIndex = 3;
            // 
            // btnLeft
            // 
            btnLeft.Animated = true;
            btnLeft.BackColor = Color.Transparent;
            btnLeft.BorderColor = Color.Transparent;
            btnLeft.CustomizableEdges = customizableEdges7;
            btnLeft.DisabledState.BorderColor = Color.DarkGray;
            btnLeft.DisabledState.CustomBorderColor = Color.DarkGray;
            btnLeft.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnLeft.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnLeft.FillColor = Color.Transparent;
            btnLeft.Font = new Font("Segoe UI", 9F);
            btnLeft.ForeColor = Color.Transparent;
            btnLeft.Image = Properties.Resources.arrow;
            btnLeft.ImageSize = new Size(60, 50);
            btnLeft.Location = new Point(336, 79);
            btnLeft.Name = "btnLeft";
            btnLeft.PressedColor = Color.Transparent;
            btnLeft.ShadowDecoration.CustomizableEdges = customizableEdges8;
            btnLeft.Size = new Size(65, 58);
            btnLeft.TabIndex = 4;
            // 
            // btnRight
            // 
            btnRight.Animated = true;
            btnRight.BackColor = Color.Transparent;
            btnRight.BorderColor = Color.Transparent;
            btnRight.CustomizableEdges = customizableEdges9;
            btnRight.DisabledState.BorderColor = Color.DarkGray;
            btnRight.DisabledState.CustomBorderColor = Color.DarkGray;
            btnRight.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnRight.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnRight.FillColor = Color.Transparent;
            btnRight.Font = new Font("Segoe UI", 9F);
            btnRight.ForeColor = Color.Transparent;
            btnRight.Image = Properties.Resources.right_arrow__1_;
            btnRight.ImageSize = new Size(60, 50);
            btnRight.Location = new Point(429, 82);
            btnRight.Name = "btnRight";
            btnRight.PressedColor = Color.Transparent;
            btnRight.ShadowDecoration.CustomizableEdges = customizableEdges10;
            btnRight.Size = new Size(66, 54);
            btnRight.TabIndex = 5;
            // 
            // btnBad
            // 
            btnBad.BackColor = Color.Transparent;
            btnBad.BorderColor = Color.Transparent;
            btnBad.CustomizableEdges = customizableEdges11;
            btnBad.DisabledState.BorderColor = Color.DarkGray;
            btnBad.DisabledState.CustomBorderColor = Color.DarkGray;
            btnBad.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnBad.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnBad.FillColor = Color.Transparent;
            btnBad.Font = new Font("Segoe UI", 9F);
            btnBad.ForeColor = Color.Transparent;
            btnBad.Image = Properties.Resources.delete_button;
            btnBad.ImageSize = new Size(60, 50);
            btnBad.Location = new Point(1795, 152);
            btnBad.Name = "btnBad";
            btnBad.PressedColor = Color.Transparent;
            btnBad.ShadowDecoration.CustomizableEdges = customizableEdges12;
            btnBad.Size = new Size(79, 54);
            btnBad.TabIndex = 6;
            // 
            // btnGood
            // 
            btnGood.BackColor = Color.Transparent;
            btnGood.BorderColor = Color.Transparent;
            btnGood.CustomizableEdges = customizableEdges13;
            btnGood.DisabledState.BorderColor = Color.DarkGray;
            btnGood.DisabledState.CustomBorderColor = Color.DarkGray;
            btnGood.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnGood.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnGood.FillColor = Color.Transparent;
            btnGood.Font = new Font("Segoe UI", 9F);
            btnGood.ForeColor = Color.Transparent;
            btnGood.Image = Properties.Resources.check_button;
            btnGood.ImageSize = new Size(60, 50);
            btnGood.Location = new Point(1533, 152);
            btnGood.Name = "btnGood";
            btnGood.PressedColor = Color.Transparent;
            btnGood.ShadowDecoration.CustomizableEdges = customizableEdges14;
            btnGood.Size = new Size(66, 54);
            btnGood.TabIndex = 7;
            // 
            // countLabel
            // 
            countLabel.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            countLabel.Location = new Point(615, 96);
            countLabel.Name = "countLabel";
            countLabel.Size = new Size(211, 40);
            countLabel.TabIndex = 8;
            countLabel.Text = "label2";
            // 
            // lstInfo
            // 
            lstInfo.Location = new Point(1479, 12);
            lstInfo.Name = "lstInfo";
            lstInfo.Size = new Size(408, 78);
            lstInfo.TabIndex = 9;
            lstInfo.UseCompatibleStateImageBehavior = false;
            lstInfo.View = View.Details;
            // 
            // star1
            // 
            star1.CustomizableEdges = customizableEdges15;
            star1.ImageRotate = 0F;
            star1.Location = new Point(1008, 28);
            star1.Name = "star1";
            star1.ShadowDecoration.CustomizableEdges = customizableEdges16;
            star1.Size = new Size(43, 25);
            star1.TabIndex = 10;
            star1.TabStop = false;
            // 
            // star2
            // 
            star2.CustomizableEdges = customizableEdges17;
            star2.ImageRotate = 0F;
            star2.Location = new Point(1086, 28);
            star2.Name = "star2";
            star2.ShadowDecoration.CustomizableEdges = customizableEdges18;
            star2.Size = new Size(43, 25);
            star2.TabIndex = 11;
            star2.TabStop = false;
            // 
            // star3
            // 
            star3.CustomizableEdges = customizableEdges19;
            star3.ImageRotate = 0F;
            star3.Location = new Point(1161, 28);
            star3.Name = "star3";
            star3.ShadowDecoration.CustomizableEdges = customizableEdges20;
            star3.Size = new Size(43, 25);
            star3.TabIndex = 12;
            star3.TabStop = false;
            // 
            // star4
            // 
            star4.CustomizableEdges = customizableEdges21;
            star4.ImageRotate = 0F;
            star4.Location = new Point(1232, 28);
            star4.Name = "star4";
            star4.ShadowDecoration.CustomizableEdges = customizableEdges22;
            star4.Size = new Size(43, 25);
            star4.TabIndex = 13;
            star4.TabStop = false;
            // 
            // star5
            // 
            star5.CustomizableEdges = customizableEdges23;
            star5.ImageRotate = 0F;
            star5.Location = new Point(1310, 28);
            star5.Name = "star5";
            star5.ShadowDecoration.CustomizableEdges = customizableEdges24;
            star5.Size = new Size(43, 25);
            star5.TabIndex = 14;
            star5.TabStop = false;
            // 
            // chkAuswhall
            // 
            chkAuswhall.Animated = true;
            chkAuswhall.AutoSize = true;
            chkAuswhall.CheckedState.BorderColor = Color.FromArgb(94, 148, 255);
            chkAuswhall.CheckedState.BorderRadius = 0;
            chkAuswhall.CheckedState.BorderThickness = 0;
            chkAuswhall.CheckedState.FillColor = Color.FromArgb(94, 148, 255);
            chkAuswhall.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            chkAuswhall.Location = new Point(1479, 96);
            chkAuswhall.Name = "chkAuswhall";
            chkAuswhall.Size = new Size(373, 34);
            chkAuswhall.TabIndex = 15;
            chkAuswhall.Text = "Bilderauswahl in Unterverzeichnissen";
            chkAuswhall.UncheckedState.BorderColor = Color.FromArgb(125, 137, 149);
            chkAuswhall.UncheckedState.BorderRadius = 0;
            chkAuswhall.UncheckedState.BorderThickness = 0;
            chkAuswhall.UncheckedState.FillColor = Color.FromArgb(125, 137, 149);
            // 
            // btnFlip
            // 
            btnFlip.BackColor = Color.Transparent;
            btnFlip.BorderColor = Color.Transparent;
            btnFlip.CustomizableEdges = customizableEdges25;
            btnFlip.DisabledState.BorderColor = Color.DarkGray;
            btnFlip.DisabledState.CustomBorderColor = Color.DarkGray;
            btnFlip.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnFlip.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnFlip.FillColor = Color.Transparent;
            btnFlip.Font = new Font("Segoe UI", 9F);
            btnFlip.ForeColor = Color.Black;
            btnFlip.Image = Properties.Resources.rotate;
            btnFlip.ImageSize = new Size(70, 60);
            btnFlip.Location = new Point(1676, 154);
            btnFlip.Name = "btnFlip";
            btnFlip.PressedColor = Color.Transparent;
            btnFlip.ShadowDecoration.CustomizableEdges = customizableEdges26;
            btnFlip.Size = new Size(62, 52);
            btnFlip.TabIndex = 16;
            // 
            // pcbPrevious
            // 
            pcbPrevious.CustomizableEdges = customizableEdges27;
            pcbPrevious.ImageRotate = 0F;
            pcbPrevious.Location = new Point(1506, 225);
            pcbPrevious.Name = "pcbPrevious";
            pcbPrevious.ShadowDecoration.CustomizableEdges = customizableEdges28;
            pcbPrevious.Size = new Size(381, 406);
            pcbPrevious.TabIndex = 17;
            pcbPrevious.TabStop = false;
            // 
            // pcbNext
            // 
            pcbNext.CustomizableEdges = customizableEdges29;
            pcbNext.ImageRotate = 0F;
            pcbNext.Location = new Point(1506, 654);
            pcbNext.Name = "pcbNext";
            pcbNext.ShadowDecoration.CustomizableEdges = customizableEdges30;
            pcbNext.Size = new Size(381, 363);
            pcbNext.TabIndex = 18;
            pcbNext.TabStop = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1807, 1061);
            Controls.Add(pcbNext);
            Controls.Add(pcbPrevious);
            Controls.Add(btnFlip);
            Controls.Add(chkAuswhall);
            Controls.Add(star5);
            Controls.Add(star4);
            Controls.Add(star3);
            Controls.Add(star2);
            Controls.Add(star1);
            Controls.Add(lstInfo);
            Controls.Add(countLabel);
            Controls.Add(btnGood);
            Controls.Add(btnBad);
            Controls.Add(btnRight);
            Controls.Add(btnLeft);
            Controls.Add(btnSelect);
            Controls.Add(pcbPhoto);
            Controls.Add(txtPath);
            Controls.Add(label1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Picturesort";
            ((System.ComponentModel.ISupportInitialize)pcbPhoto).EndInit();
            ((System.ComponentModel.ISupportInitialize)star1).EndInit();
            ((System.ComponentModel.ISupportInitialize)star2).EndInit();
            ((System.ComponentModel.ISupportInitialize)star3).EndInit();
            ((System.ComponentModel.ISupportInitialize)star4).EndInit();
            ((System.ComponentModel.ISupportInitialize)star5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pcbPrevious).EndInit();
            ((System.ComponentModel.ISupportInitialize)pcbNext).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Guna.UI2.WinForms.Guna2TextBox txtPath;
        private Guna.UI2.WinForms.Guna2PictureBox pcbPhoto;
        private Guna.UI2.WinForms.Guna2Button btnSelect;
        private Guna.UI2.WinForms.Guna2Button btnLeft;
        private Guna.UI2.WinForms.Guna2Button btnRight;
        private Guna.UI2.WinForms.Guna2Button btnBad;
        private Guna.UI2.WinForms.Guna2Button btnGood;
        private Label countLabel;
        private ListView lstInfo;
        private Guna.UI2.WinForms.Guna2PictureBox star1;
        private Guna.UI2.WinForms.Guna2PictureBox star2;
        private Guna.UI2.WinForms.Guna2PictureBox star3;
        private Guna.UI2.WinForms.Guna2PictureBox star4;
        private Guna.UI2.WinForms.Guna2PictureBox star5;
        private Guna.UI2.WinForms.Guna2CheckBox chkAuswhall;
        private Guna.UI2.WinForms.Guna2Button btnFlip;
        private Guna.UI2.WinForms.Guna2PictureBox pcbPrevious;
        private Guna.UI2.WinForms.Guna2PictureBox pcbNext;
    }
}